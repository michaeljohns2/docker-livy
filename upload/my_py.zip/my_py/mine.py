
class Mine:
    @staticmethod
    def tryMe():
        return "methods are available in tryMe!"
